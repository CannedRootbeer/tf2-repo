// SOURCE ONLY - NOT BUILT, NOT TESTED. Skeleton for a BepInEx 5 plugin on R.E.P.O.
using BepInEx;
using UnityEngine;

[BepInPlugin("mashup.tf2classes", "TF2 Classes in R.E.P.O.", "0.1.0")]
public class TF2ClassesPlugin : BaseUnityPlugin
{
    static readonly string[] Classes = {"scout","soldier","pyro","demoman","heavy","engineer","medic","sniper","spy"};
    string tf2Dir;

    void Awake()
    {
        tf2Dir = System.Environment.GetEnvironmentVariable("TF2CLASSES_TF2_DIR"); // set by Melty; never copy TF2 files
        Logger.LogInfo("TF2 folder: " + tf2Dir);
    }

    void Update()
    {
        // TODO: real class menu at the truck. F1-F9 is a stand-in for early testing.
        for (int i = 0; i < Classes.Length; i++)
            if (Input.GetKeyDown(KeyCode.F1 + i)) Apply(Classes[i]);
    }

    void Apply(string id)
    {
        // TODO: read the row from sheets/classes.json, set health/speed via verified R.E.P.O. hooks,
        // load weapon models/sounds from the player's TF2 VPKs at runtime.
        Logger.LogInfo("Selected class: " + id);
    }
}
