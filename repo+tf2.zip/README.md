# TF2 Classes in R.E.P.O. (draft)
Solo only. R.E.P.O. is the host (BepInEx 5); Team Fortress 2 is a companion game whose files are read from the player's own install. All 9 TF2 classes, picked at the truck before each level. MIT, remixing allowed.

STATUS: design sheets + untested skeleton only. Nothing is built, tested, screenshotted or published.
Remaining: verify R.E.P.O. hooks (sheets/classes.json, verified:false), build the class menu, read TF2 VPK assets at runtime, build, preflight, one_click_check, test_release, real screenshot, publish via Melty.
